func vvv_sig1(name string) string {
	return ""
}