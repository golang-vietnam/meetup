package codes

// MODEL START OMIT
// Model
type User struct {
	Username string // HL
	Age      int
}

// MODEL END OMIT

// HANDLER START OMIT
// Handler
func handle() {
	//...
	u := &User{"Gopher", 17}
	tmpl.Execute(u) // HL
}

// HANDLER END OMIT
