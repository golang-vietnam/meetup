package codes

// START OMIT
type helloTemplate struct {
}

func (tmpl *helloTemplate) Render(user *User) ([]byte, error) {
	data := map[string]interface{}{
		"User": user,
	}
	return tmpl.ActualTmpl.Execute(data)
}

// END OMIT
